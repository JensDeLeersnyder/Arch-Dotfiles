applet.currentConfigGroup = new Array("General");
applet.writeConfig("buttonSizePercentage","70");
applet.writeConfig("containmentType","Plasma");
applet.writeConfig("inactiveStateEnabled","true");
applet.writeConfig("visibility","ActiveMaximizedWindow");
applet.reloadConfig();