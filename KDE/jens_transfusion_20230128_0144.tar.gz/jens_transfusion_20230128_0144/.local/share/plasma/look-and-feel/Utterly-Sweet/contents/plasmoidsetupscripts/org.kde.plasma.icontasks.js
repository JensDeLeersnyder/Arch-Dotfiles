applet.currentConfigGroup = new Array("General");
applet.writeConfig("groupedTaskVisualization","2");
applet.writeConfig("maxStripes","1");
applet.writeConfig("showOnlyCurrentScreen","true");
applet.writeConfig("showOnlyCurrentActivity","true");
applet.writeConfig("showOnlyCurrentDesktop","true");
applet.writeConfig("wheelSkipMinimized","false");
applet.reloadConfig();